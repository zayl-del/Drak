DRAK – natívny Android projekt so súkromnou databázou SQLite

Tento ZIP obsahuje zdrojový projekt a workflow na zostavenie APK v cloudovom prostredí GitHub Actions. APK ešte nie je súčasťou ZIP-u.

FUNKCIE ZÁKLADU
- základ románu: názov, žáner, námet, štýl, pravidlá
- kapitoly, osnova, text a cieľový počet slov
- postavy, vedomosti a aktuálny stav
- časová os a pamäťové poznámky
- zadanie pre ChatGPT skopírované do schránky
- vlastná SQLite databáza v súkromnom priestore aplikácie

DÔLEŽITÉ
- Aplikácia sama negeneruje text cez AI; používa sa existujúci ChatGPT kopírovaním.
- Zatiaľ nie je hotový export/import celej databázy. Pred odinštalovaním by sa údaje mohli stratiť.
- APK ešte treba zostaviť a otestovať na telefóne.
- GitHub Actions používa cloudové zostavenie. Pri bežnom použití môže byť bezplatné v rámci kvót GitHubu; dostupnosť a limity závisia od účtu a nastavení.

AKO ZOSTAVIŤ APK CEZ GITHUB ACTIONS
1. Na GitHub.com vytvor nový repozitár (môže byť súkromný).
2. Nahraj doň obsah tohto priečinka tak, aby `app/`, `build.gradle`, `settings.gradle` a `.github/workflows/build-apk.yml` boli v koreňovom adresári repozitára.
3. Otvor kartu Actions a povoľ Actions, ak sa na to GitHub opýta.
4. Po nahratí na vetvu `main` sa workflow spustí automaticky. Prípadne v Actions vyber „Build DRAK APK“ a stlač „Run workflow“.
5. Po úspešnom dokončení otvor daný beh a v časti Artifacts stiahni `DRAK-debug-APK`. ZIP artifact obsahuje `app-debug.apk`.
6. Stiahni APK do telefónu, otvor ho a povoľ inštaláciu z daného zdroja, ak to Android vyžiada.

Cloud workflow nastavuje Javu a Gradle. GitHub-hosted runner má Android SDK k dispozícii. Tento workflow som pripravil, ale ešte som ho v skutočnom GitHub repozitári nespustil; zostavenie teda zatiaľ nie je overené.
