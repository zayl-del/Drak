package sk.drak.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;

public class MainActivity extends Activity {
    DrakDb db;
    LinearLayout root, content, nav;
    String current = "home";
    int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DrakDb(this);
        getWindow().setStatusBarColor(0xff151923);
        getWindow().setNavigationBarColor(0xff10131a);
        showShell();
        render();
    }
    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(0xffeef2fb); if (bold) t.setTypeface(null, 1);
        t.setPadding(0, dp(5), 0, dp(5)); return t;
    }
    Button button(String s, Runnable r) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false);
        b.setOnClickListener(v -> r.run()); return b;
    }
    void showShell() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xff10131a);
        TextView head = text("🐉  DRAK\nTvorba románov", 22, true);
        head.setPadding(dp(16),dp(14),dp(16),dp(12)); head.setBackgroundColor(0xff191f2b); root.addView(head);
        HorizontalScrollView hsv = new HorizontalScrollView(this); nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL);
        String[][] tabs = {{"home","Prehľad"},{"project","Román"},{"chapters","Kapitoly"},{"characters","Postavy"},{"timeline","Časová os"},{"notes","Pamäť"},{"backup","Export"}};
        for (String[] t: tabs) nav.addView(button(t[1], () -> { current=t[0]; render(); }));
        hsv.addView(nav); root.addView(hsv);
        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14),dp(12),dp(14),dp(28)); scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void add(View v) { content.addView(v); }
    void label(String s) { add(text(s,18,true)); }
    EditText edit(String hint, String value, int lines) {
        EditText e = new EditText(this); e.setHint(hint); e.setText(value == null ? "" : value);
        e.setTextColor(0xffeef2fb); e.setHintTextColor(0xffaab6cc); e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff7e8ca5));
        e.setPadding(dp(10),dp(8),dp(10),dp(8)); e.setMinLines(lines); e.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(3),0,dp(7)); e.setLayoutParams(lp); return e;
    }
    String val(EditText e) { return e.getText().toString().trim(); }
    void render() {
        content.removeAllViews();
        switch(current) {
            case "project": project(); break;
            case "chapters": chapters(); break;
            case "characters": characters(); break;
            case "timeline": timeline(); break;
            case "notes": notes(); break;
            case "backup": backup(); break;
            default: home();
        }
    }
    void home() {
        Cursor p = db.rows("SELECT title FROM project WHERE id=1"); String title="Môj román"; if(p.moveToFirst()) title=p.getString(0); p.close();
        Cursor c=db.rows("SELECT COUNT(*), COALESCE(SUM(LENGTH(content)-LENGTH(REPLACE(content,' ',''))+1),0) FROM chapters");
        int count=0; if(c.moveToFirst()) count=c.getInt(0); c.close();
        label("Vitaj v DRAK-u"); add(text(title,21,true));
        add(text("Samostatná Android aplikácia s vlastnou databázou SQLite v súkromnom priestore aplikácie.",15,false));
        add(text("Kapitoly: "+count+"   •   Údaje sa ukladajú v telefóne",15,true));
        add(text("Ako pracovať: nastav román, pridaj postavy a osnovu kapitoly, vytvor zadanie pre ChatGPT a výsledný text vlož späť do kapitoly.",15,false));
        add(button("＋ Nová kapitola", () -> { current="chapters"; render(); addChapterDialog(); }));
        add(text("Dôležité: DRAK sám neposiela správy do ChatGPT. Používa sa existujúci ChatGPT cez kopírovanie textu; API kľúč netreba.",13,false));
    }
    void project() {
        Cursor c=db.rows("SELECT title,genre,premise,style,rules FROM project WHERE id=1");
        String[] v={"Môj román","Fantasy","","",""}; if(c.moveToFirst()) for(int i=0;i<5;i++)v[i]=c.getString(i); c.close();
        label("Základ románu");
        EditText title=edit("Názov románu",v[0],1), genre=edit("Žáner",v[1],1), premise=edit("Námet a hlavný konflikt",v[2],4), style=edit("Štýl a tón",v[3],3), rules=edit("Pravidlá sveta a fakty, ktoré sa nesmú porušiť",v[4],5);
        add(title);add(genre);add(premise);add(style);add(rules);
        add(button("Uložiť román", () -> {db.update("project",db.values("title",val(title),"genre",val(genre),"premise",val(premise),"style",val(style),"rules",val(rules)),"id=1",null); toast("Román uložený");}));
    }
    void chapters() {
        label("Kapitoly");
        add(button("＋ Vytvoriť kapitolu", () -> addChapterDialog()));
        Cursor c=db.rows("SELECT id,title,status,target_words,content,outline FROM chapters ORDER BY id");
        while(c.moveToNext()) {
            int id=c.getInt(0); String title=c.getString(1), status=c.getString(2); int target=c.getInt(3); String body=c.getString(4), outline=c.getString(5);
            add(text(id+". "+title,18,true)); add(text(status+" • "+wordCount(body)+" / "+target+" slov",13,false));
            add(button("Otvoriť / upraviť", () -> editChapter(id)));
        } c.close();
    }
    void addChapterDialog() {
        EditText title=edit("Názov kapitoly","Kapitola",1), target=edit("Cieľový počet slov","8000",1), outline=edit("Osnova kapitoly","",5);
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(16),dp(8),dp(16),dp(8)); box.setOrientation(1);box.addView(title);box.addView(target);box.addView(outline);
        new AlertDialog.Builder(this).setTitle("Nová kapitola").setView(box).setNegativeButton("Zrušiť",null).setPositiveButton("Vytvoriť",(d,w)->{
            ContentValues cv=new ContentValues();cv.put("title",val(title).isEmpty()?"Kapitola":val(title));cv.put("target_words",parseInt(val(target),8000));cv.put("outline",val(outline));cv.put("status","Plán");cv.put("content","");
            db.insert("chapters",cv);render();toast("Kapitola vytvorená");
        }).show();
    }
    void editChapter(int id) {
        Cursor c=db.rows("SELECT title,outline,target_words,status,content FROM chapters WHERE id=?",String.valueOf(id));
        if(!c.moveToFirst()){c.close();return;}
        String[] v={c.getString(0),c.getString(1),String.valueOf(c.getInt(2)),c.getString(3),c.getString(4)};c.close();
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(16),dp(8),dp(16),dp(8));
        ScrollView sv=new ScrollView(this);LinearLayout fields=new LinearLayout(this);fields.setOrientation(1);
        EditText title=edit("Názov",v[0],1), outline=edit("Osnova",v[1],4), target=edit("Cieľ slov",v[2],1), status=edit("Stav (Plán/Rozpracovaná/Kontrola/Hotová)",v[3],1), body=edit("Text kapitoly",v[4],12);
        fields.addView(title);fields.addView(outline);fields.addView(target);fields.addView(status);fields.addView(body);sv.addView(fields);
        new AlertDialog.Builder(this).setTitle("Upraviť kapitolu").setView(sv).setNegativeButton("Zavrieť",null).setNeutralButton("Vytvoriť zadanie",(d,w)->{
            db.update("chapters",db.values("title",val(title),"outline",val(outline),"target_words",val(target),"status",val(status),"content",val(body)),"id=?",new String[]{String.valueOf(id)});
            String prompt=makePrompt(id);copy(prompt);toast("Zadanie skopírované. Vlož ho do ChatGPT.");
        }).setPositiveButton("Uložiť",(d,w)->{
            db.update("chapters",db.values("title",val(title),"outline",val(outline),"target_words",val(target),"status",val(status),"content",val(body)),"id=?",new String[]{String.valueOf(id)});
            render();toast("Kapitola uložená");
        }).show();
    }
    String makePrompt(int id) {
        Cursor p=db.rows("SELECT title,genre,premise,style,rules FROM project WHERE id=1");String proj="";if(p.moveToFirst())proj="ROMÁN: "+p.getString(0)+"\nŽÁNER: "+p.getString(1)+"\nNÁMET: "+p.getString(2)+"\nŠTÝL: "+p.getString(3)+"\nPRAVIDLÁ: "+p.getString(4);p.close();
        Cursor c=db.rows("SELECT title,outline,target_words FROM chapters WHERE id=?",String.valueOf(id));String title="",outline="";int target=8000;if(c.moveToFirst()){title=c.getString(0);outline=c.getString(1);target=c.getInt(2);}c.close();
        StringBuilder chars=new StringBuilder();Cursor cc=db.rows("SELECT name,description,knows,status FROM characters");while(cc.moveToNext())chars.append("- ").append(cc.getString(0)).append(": ").append(cc.getString(1)).append("; vie/neví: ").append(cc.getString(2)).append("; stav: ").append(cc.getString(3)).append("\n");cc.close();
        StringBuilder tl=new StringBuilder();Cursor tt=db.rows("SELECT moment,event,consequences FROM timeline");while(tt.moveToNext())tl.append("- ").append(tt.getString(0)).append(": ").append(tt.getString(1)).append("; následky: ").append(tt.getString(2)).append("\n");tt.close();
        StringBuilder ns=new StringBuilder();Cursor nn=db.rows("SELECT title,body FROM notes");while(nn.moveToNext())ns.append("- ").append(nn.getString(0)).append(": ").append(nn.getString(1)).append("\n");nn.close();
        return "PÍŠEŠ ROMÁN. Dodrž kontinuitu a fakty.\n\n"+proj+"\n\nKAPITOLA: "+title+"\nCIEĽ: približne "+target+" slov. Ak je to priveľa na jednu odpoveď, rozdeľ výstup na časti bez opakovania.\nOSNOVA:\n"+outline+"\n\nPOSTAVY:\n"+chars+"\nČASOVÁ OS:\n"+tl+"\nPAMÄŤ:\n"+ns+"\n\nPíš literárne, konkrétne, bez vaty a rozporov. Začni samotným textom kapitoly.";
    }
    int wordCount(String s){if(s==null||s.trim().isEmpty())return 0;return s.trim().split("\\s+").length;}
    int parseInt(String s,int def){try{return Integer.parseInt(s);}catch(Exception e){return def;}}
    void characters() {
        label("Postavy"); EditText name=edit("Meno postavy","",1),desc=edit("Povaha, vzhľad, motivácia","",3),knows=edit("Čo vie a čo nevie","",3),status=edit("Aktuálny stav / miesto / vzťahy","",3);
        add(name);add(desc);add(knows);add(status);add(button("Uložiť postavu",()->{if(val(name).isEmpty()){toast("Zadaj meno");return;}db.insert("characters",db.values("name",val(name),"description",val(desc),"knows",val(knows),"status",val(status)));render();toast("Postava uložená");}));
        Cursor c=db.rows("SELECT id,name,description,knows,status FROM characters ORDER BY name");while(c.moveToNext()){int id=c.getInt(0);add(text(c.getString(1),18,true));add(text(c.getString(2)+"\nVie/neví: "+c.getString(3)+"\nStav: "+c.getString(4),14,false));add(button("Odstrániť "+c.getString(1),()->{db.delete("characters","id=?",new String[]{String.valueOf(id)});render();}));}c.close();
    }
    void timeline() {
        label("Časová os");EditText moment=edit("Kedy / v ktorej kapitole","",1),event=edit("Čo sa stalo","",3),cons=edit("Dôsledky","",3);add(moment);add(event);add(cons);
        add(button("Uložiť udalosť",()->{if(val(moment).isEmpty()){toast("Doplň čas alebo kapitolu");return;}db.insert("timeline",db.values("moment",val(moment),"event",val(event),"consequences",val(cons)));render();}));
        Cursor c=db.rows("SELECT id,moment,event,consequences FROM timeline ORDER BY id");while(c.moveToNext()){int id=c.getInt(0);add(text(c.getString(1),18,true));add(text(c.getString(2)+"\nDôsledky: "+c.getString(3),14,false));add(button("Odstrániť udalosť",()->{db.delete("timeline","id=?",new String[]{String.valueOf(id)});render();}));}c.close();
    }
    void notes() {
        label("Pamäť románu");EditText title=edit("Názov poznámky","",1),body=edit("Fakt, tajomstvo, otvorená dejová línia","",4);add(title);add(body);add(button("Uložiť poznámku",()->{if(val(title).isEmpty()){toast("Doplň názov");return;}db.insert("notes",db.values("title",val(title),"body",val(body)));render();}));
        Cursor c=db.rows("SELECT id,title,body FROM notes ORDER BY id DESC");while(c.moveToNext()){int id=c.getInt(0);add(text(c.getString(1),18,true));add(text(c.getString(2),14,false));add(button("Odstrániť poznámku",()->{db.delete("notes","id=?",new String[]{String.valueOf(id)});render();}));}c.close();
    }
    void backup() {
        label("Export a záloha");
        add(text("Databáza sa nachádza v súkromnom úložisku aplikácie. V tejto základnej verzii nie je automatický cloud; pred odinštalovaním aplikácie treba pridať export/import zálohy.",14,false));
        add(button("Skopírovať prehľad románu",()->{
            Cursor c=db.rows("SELECT title,genre,premise,style,rules FROM project WHERE id=1");String s="";if(c.moveToFirst())s="Názov: "+c.getString(0)+"\nŽáner: "+c.getString(1)+"\nNámet: "+c.getString(2)+"\nŠtýl: "+c.getString(3)+"\nPravidlá: "+c.getString(4);c.close();copy(s);toast("Prehľad skopírovaný");
        }));
        add(button("Skopírovať celý rukopis",()->{
            StringBuilder s=new StringBuilder();Cursor c=db.rows("SELECT title,content FROM chapters ORDER BY id");while(c.moveToNext())s.append(c.getString(0)).append("\n\n").append(c.getString(1)).append("\n\n\n");c.close();copy(s.toString());toast("Rukopis skopírovaný");
        }));
    }
    void copy(String s) { ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("DRAK",s)); }
    void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
