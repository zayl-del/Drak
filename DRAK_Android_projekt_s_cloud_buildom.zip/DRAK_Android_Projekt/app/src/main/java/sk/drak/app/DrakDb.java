package sk.drak.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DrakDb extends SQLiteOpenHelper {
    public DrakDb(Context c) { super(c, "drak_library.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE project (id INTEGER PRIMARY KEY CHECK(id=1), title TEXT, genre TEXT, premise TEXT, style TEXT, rules TEXT)");
        d.execSQL("INSERT INTO project(id,title,genre,premise,style,rules) VALUES(1,'Môj román','Fantasy','','','')");
        d.execSQL("CREATE TABLE chapters (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, outline TEXT, target_words INTEGER DEFAULT 8000, status TEXT DEFAULT 'Plán', content TEXT DEFAULT '')");
        d.execSQL("CREATE TABLE characters (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, description TEXT, knows TEXT, status TEXT)");
        d.execSQL("CREATE TABLE timeline (id INTEGER PRIMARY KEY AUTOINCREMENT, moment TEXT, event TEXT, consequences TEXT)");
        d.execSQL("CREATE TABLE notes (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, body TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase d, int oldV, int newV) {}
    public Cursor rows(String sql, String... args) { return getReadableDatabase().rawQuery(sql, args); }
    public long insert(String table, ContentValues values) { return getWritableDatabase().insert(table, null, values); }
    public int update(String table, ContentValues values, String where, String[] args) { return getWritableDatabase().update(table, values, where, args); }
    public int delete(String table, String where, String[] args) { return getWritableDatabase().delete(table, where, args); }
    public ContentValues values(String... pairs) {
        ContentValues v = new ContentValues();
        for (int i=0; i+1<pairs.length; i+=2) v.put(pairs[i], pairs[i+1]);
        return v;
    }
}
